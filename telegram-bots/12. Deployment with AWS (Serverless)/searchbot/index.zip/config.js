const helpMessage =
  `
Welcome to Search Bot!
Use the inline mode below
@s300bot p <search image>
@s300bot w <search wiki>
`;

module.exports = {
  helpMessage
}